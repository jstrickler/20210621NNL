#!/usr/bin/env python
# (c) 2017 NOAA
# 
"""
Doc string goes here...
"""
import numpy as np
import netcdf4
